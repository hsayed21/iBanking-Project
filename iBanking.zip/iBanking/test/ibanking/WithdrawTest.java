/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibanking;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HS
 */
public class WithdrawTest {
    
    public WithdrawTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of change_data method, of class Withdraw.
     */
    @Test
    public void testChange_data() {
        System.out.println("change_data");
        String accountID = "111";
        double balance = 2000;
        Withdraw instance = new Withdraw();
        instance.change_data(accountID, balance);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of withdrawMoney method, of class Withdraw.
     */
    @Test
    public void testWithdrawMoney() {
        System.out.println("withdrawMoney");
        double balance = 1000;
        Withdraw instance = new Withdraw();
        instance.withdrawMoney(balance);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Withdraw.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Withdraw.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
