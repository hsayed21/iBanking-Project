/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibanking;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HS
 */
public class DepositTest {
    
    public DepositTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of change_data method, of class Deposit.
     */
    @Test
    public void testChange_data() {
        System.out.println("change_data");
        String accountID = "111";
        double balance = 2000;
        Deposit instance = new Deposit();
        instance.change_data(accountID, balance);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of updataAccount method, of class Deposit.
     */
    @Test
    public void testUpdataAccount() {
        System.out.println("updataAccount");
        double balance = 0.0;
        Deposit instance = new Deposit();
        instance.updataAccount(balance);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Deposit.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Deposit.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
