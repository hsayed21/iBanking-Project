/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibanking;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HS
 */
public class AddAccountTest {
    
    public AddAccountTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addAccount method, of class AddAccount.
     */
    @Test
    public void testAddAccount() {
        System.out.println("addAccount");
        String accountID = "454";
        String username = "aaa";
        String password = "aaa";
        String balance = "1540";
        String phoneNumber = "12345678900";
        String fName = "aaa";
        String lName = "aaa";
        String age = "111";
        String dob = "2020-1-1";
        String address = "aaa";
        String nationality = "aaa";
        String gender = "Male";
        AddAccount instance = new AddAccount();
        instance.addAccount(accountID, username, password, balance, phoneNumber, fName, lName, age, dob, address, nationality, gender);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class AddAccount.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        AddAccount.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
