/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibanking;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HS
 */
public class TransactionTest {
    
    public TransactionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of change_data method, of class Transaction.
     */
    @Test
    public void testChange_data() {
        System.out.println("change_data");
        String accountID = "111";
        double balance = 500;
        Transaction instance = new Transaction();
        instance.change_data(accountID, balance);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of transferMoney method, of class Transaction.
     */
    @Test
    public void testTransferMoney() {
        System.out.println("transferMoney");
        double balance_to = 111;
        int to = 222;
        double balance = 300;
        Transaction instance = new Transaction();
        instance.transferMoney(balance_to, to, balance);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Transaction.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Transaction.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
