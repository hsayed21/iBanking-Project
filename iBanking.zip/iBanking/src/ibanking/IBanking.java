/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibanking;

import java.awt.Dimension;

/**
 *
 * @author HS
 */
public class IBanking {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Login lf = new Login();
        //lf.setPreferredSize(new Dimension(1276, 943));
        //lf.pack();
        lf.setTitle("Login");
        lf.setVisible(true);
        lf.setSize(1310, 940);
        //lf.setLocation(100,100);
        lf.setResizable(false);
        lf.setLocationRelativeTo(null);   //center jframe
    }
    
}
